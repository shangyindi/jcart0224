package com.shangyd.jcartadministrationback.service;

import com.shangyd.jcartadministrationback.po.Address;

public interface AddressService {
    Address getById(Integer addressId);
}
