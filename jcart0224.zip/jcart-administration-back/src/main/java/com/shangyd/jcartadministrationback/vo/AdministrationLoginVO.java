package com.shangyd.jcartadministrationback.vo;

public class AdministrationLoginVO {
    private Integer administrationId;
    private String username;

    public Integer getAdministrationId() {
        return administrationId;
    }

    public void setAdministrationId(Integer administrationId) {
        this.administrationId = administrationId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
