package com.shangyd.jcartstoreback.eunm;

public enum ShipMethodEnum {
    //邮政
    EMS,
    //顺丰
    SF,
    //中通
    ZF,
    //韵达
    YD,
    //申通
    ST,
    //天天
    TT
}
