package com.shangyd.jcartstoreback.vo;

public class CustomerLoginVo {
    private Integer customerId;
    private String username;

    public Integer getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Integer customerId) {
        this.customerId = customerId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
