package com.shangyd.jcartstoreback.eunm;

public enum ReturnStatus {
    pending,
    Forpickup,
    Theprocessing,
    Finish,
    refuse
}
